#!/usr/bin/env node
/*
 * atem-levels.js — ATEM bridge for autocut v1.1.1.
 *
 * Owns the ATEM connection via atem-connection. Talks to Python over stdio.
 * This build is verbose: on connect it reports the real Fairlight source IDs,
 * tries every available way to ENABLE metering (the ATEM does not stream
 * meter levels unless asked), and logs what level data actually arrives so
 * we can pin the right source IDs and dB field.
 *
 *   stdout (one JSON object per line):
 *     {"type":"status","connected":true}
 *     {"type":"levels","inputs":{"1001":-42.3,"1002":-55.1}}
 *     {"type":"program","input":2}
 *     {"type":"log","msg":"..."}
 *   stdin:
 *     {"connect":"192.168.x.x"}  {"cut":3}  {"subscribe":[1001,1002]}
 */

const readline = require('readline');

let conn;
try { conn = require('atem-connection'); }
catch (e) { out({ type:'log', msg:'atem-connection not installed: ' + e.message }); process.exit(1); }

const { Atem, Commands } = conn;

function out(o) { try { process.stdout.write(JSON.stringify(o) + '\n'); } catch {} }
function log(m) { out({ type:'log', msg:m }); }

let atem = null;
let connected = false;
let subscribed = [1, 2];
let lastSent = 0;
let lastMasterSent = 0;
let seenCmds = new Set();      // distinct received command names (diagnostic)
let loggedSample = false;
let levelsArrived = false;

function connect(ip) {
  if (atem) { try { atem.disconnect(); } catch {} atem = null; }
  atem = new Atem();

  atem.on('connected', () => {
    connected = true;
    out({ type:'status', connected:true });
    log('connected to ' + ip);

    // 1) Report real Fairlight source IDs
    try {
      const fl = atem.state?.fairlight;
      if (fl && fl.inputs) {
        for (const [inputId, inp] of Object.entries(fl.inputs)) {
          const srcIds = Object.keys(inp?.sources ?? {});
          log(`fairlight input ${inputId}  sources=[${srcIds.join(', ')}]`);
        }
      } else {
        log('no fairlight state — this ATEM may use the classic audio mixer');
        const cl = atem.state?.audio?.channels;
        if (cl) log('classic audio channels: [' + Object.keys(cl).join(', ') + ']');
      }
    } catch (e) { log('input dump error: ' + e.message); }

    // 2) Introspect: what level-enable methods / commands exist?
    try {
      const proto = Object.getPrototypeOf(atem);
      const methods = Object.getOwnPropertyNames(proto)
        .filter(n => /level/i.test(n));
      log('atem methods matching /level/: [' + methods.join(', ') + ']');
      const cmds = Object.keys(Commands || {})
        .filter(n => /level/i.test(n) || /sendlevels/i.test(n));
      log('Commands matching /level/: [' + cmds.join(', ') + ']');
    } catch (e) { log('introspect error: ' + e.message); }

    // 3) Try to ENABLE metering, every way we know
    enableLevels();

    // current program
    try { out({ type:'program', input: atem.state.video.mixEffects[0].programInput }); } catch {}
    // input labels (camera names from ATEM)
    sendLabels();
  });

  atem.on('disconnected', () => { connected = false; out({ type:'status', connected:false }); });
  atem.on('error', e => log('atem error: ' + (e?.message || e)));

  atem.on('stateChanged', (state, paths) => {
    for (const p of paths) {
      if (p.includes('programInput')) {
        try { out({ type:'program', input: state.video.mixEffects[0].programInput }); } catch {}
      }
      if (p.includes('inputs') && p.includes('settings')) sendLabels();
    }
  });

  atem.on('receivedCommands', (commands) => {
    const now = Date.now();
    const inputs = {};
    let dirty = false;
    let masterDb = null;
    for (const cmd of commands) {
      const name = cmd?.constructor?.name ?? '';
      if (/level/i.test(name) && !seenCmds.has(name)) {
        seenCmds.add(name);
        log('RX command: ' + name);
      }
      // PGM (master) audio meter — the real program bus level
      if (/FairlightMixerMasterLevels|MasterLevels|AudioMasterLevels/i.test(name)) {
        const props = cmd.properties ?? cmd;
        const v = pickDb(props);
        if (v !== null) masterDb = v;
      }
      if (/FairlightMixerSourceLevels|FairlightMixerLevels|AudioMixerLevels|AudioLevels/i.test(name)) {
        const props = cmd.properties ?? cmd;
        const id = Number(cmd.index ?? cmd.inputId ?? cmd.fairlightAudioSourceId
                          ?? props.index ?? props.inputId);
        if (!loggedSample) {
          loggedSample = true;
          log('cmd top-level keys: [' + Object.keys(cmd).join(', ') + ']');
          log('extracted id=' + id + '  source=' + (cmd.source ?? '?'));
          log('level sample keys: [' + Object.keys(props).join(', ') + ']');
        }
        const v = pickDb(props);
        if (v !== null && (subscribed.length === 0 || subscribed.includes(id))) {
          inputs[id] = v; dirty = true;
          if (!levelsArrived) { levelsArrived = true; log('LEVELS FLOWING ✓ (id ' + id + ' = ' + v.toFixed(1) + ' dB)'); }
        }
      }
    }
    if (dirty && now - lastSent >= 30) { lastSent = now; out({ type:'levels', inputs }); }
    if (masterDb !== null && now - lastMasterSent >= 30) {
      lastMasterSent = now;
      out({ type:'master-level', db: masterDb });
    }
  });

  atem.connect(ip);
  log('connecting to ' + ip + ' …');
}

function enableLevels() {
  // Try high-level methods first, then raw commands. All wrapped so a wrong
  // name just logs instead of crashing.
  const attempts = [];

  // High-level method candidates
  for (const m of ['setAudioMixerLevelsEnabled', 'setFairlightAudioMixerLevelsEnabled',
                   'setAudioLevelsEnabled', 'requestAudioLevels', 'sendAudioLevels']) {
    if (typeof atem[m] === 'function') {
      attempts.push(['method ' + m, () => atem[m](true)]);
    }
  }
  // Raw command candidates
  for (const c of ['FairlightMixerSendLevelsCommand', 'AudioMixerSendLevelsCommand',
                   'FairlightMixerSendLevels', 'AudioLevelsCommand']) {
    if (Commands && typeof Commands[c] === 'function') {
      attempts.push(['command ' + c, () => {
        let cmd;
        try { cmd = new Commands[c](true); } catch { cmd = new Commands[c](); if ('enabled' in cmd) cmd.enabled = true; }
        return atem.sendCommand(cmd);
      }]);
    }
  }

  if (!attempts.length) {
    log('WARNING: no level-enable method/command found in this atem-connection version');
    return;
  }
  (async () => {
    for (const [label, fn] of attempts) {
      try { await fn(); log('enable levels: tried ' + label + ' ✓'); }
      catch (e) { log('enable levels: ' + label + ' failed: ' + (e?.message || e)); }
    }
  })();
}

function sendLabels() {
  try {
    const inputs = atem.state?.inputs ?? {};
    const labels = {};
    for (const [id, inp] of Object.entries(inputs)) {
      const name = inp?.longName || inp?.shortName;
      if (name) labels[id] = name;
    }
    if (Object.keys(labels).length) out({ type: 'labels', labels });

    // Also emit the Fairlight source IDs we can see (mic inputs, hdmi, etc.)
    const fl = atem.state?.fairlight?.inputs ?? {};
    const sourceIds = Object.keys(fl).map(Number).filter(n => !isNaN(n));
    if (sourceIds.length) out({ type: 'sources', ids: sourceIds });
  } catch (e) { log('label read error: ' + e.message); }
}

// ── Network discovery: ATEMs reply to a UDP HELLO on :9910 ──
function discover() {
  const dgram = require('dgram');
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  const found = {};
  const hello = Buffer.from([0x10, 0x14, 0x53, 0xab, 0x00, 0x00, 0x00, 0x00,
                             0x00, 0x3a, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
                             0x00, 0x00, 0x00, 0x00]);
  sock.on('error', () => { try { sock.close(); } catch {} });
  sock.on('message', (msg, rinfo) => {
    if (!found[rinfo.address]) {
      found[rinfo.address] = true;
      out({ type: 'discovered', ip: rinfo.address });
    }
  });
  sock.bind(() => {
    try { sock.setBroadcast(true); } catch {}
    try { sock.send(hello, 0, hello.length, 9910, '255.255.255.255'); } catch {}
  });
  setTimeout(() => { try { sock.close(); } catch {} out({ type: 'discoverDone' }); }, 2500);
}

function pickDb(props) {
  // atem-connection reports Fairlight levels in HUNDREDTHS of a dB
  // (e.g. -4845 = -48.45 dBFS). Prefer input level, fall back to output.
  const raw = [
    props.inputLeftLevel, props.inputRightLevel,
    props.leftLevel, props.rightLevel,
    props.outputLeftLevel, props.outputRightLevel,
  ].filter(x => typeof x === 'number');
  if (!raw.length) return null;
  return Math.max(...raw) / 100;
}

function safeJson(o) {
  try { return JSON.stringify(o, (k,v)=> typeof v==='bigint'? Number(v): v).slice(0, 300); }
  catch { return '(unserializable)'; }
}

function cut(input) {
  if (!atem || !connected) { log('cut ignored: not connected'); return; }
  atem.changeProgramInput(Number(input)).catch(e => log('cut failed: ' + (e?.message || e)));
}

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', (line) => {
  line = line.trim(); if (!line) return;
  let msg; try { msg = JSON.parse(line); } catch { return; }
  if (msg.connect) connect(String(msg.connect));
  if (msg.cut !== undefined) cut(msg.cut);
  if (msg.discover) discover();
  if (Array.isArray(msg.subscribe)) {
    subscribed = msg.subscribe.map(Number);
    log('subscribed to ids: [' + subscribed.join(', ') + ']');
  }
});

process.on('SIGTERM', () => { try { atem?.disconnect(); } catch {} process.exit(0); });
process.on('SIGINT',  () => { try { atem?.disconnect(); } catch {} process.exit(0); });

log('helper ready (diagnostic build)');
