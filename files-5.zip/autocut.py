#!/usr/bin/env python3
"""
autocut.py — ATEM auto-switcher launcher (Companion-style).

Launcher picks a bind IP/port and manages saved scenes (one per
podcast). Production controls (meters, knobs, mapping) live in the web
dashboard at dashboard.html, served by this process.

Levels & cutting are handled by a bundled Node helper (atem-levels.js)
using atem-connection — the same library Companion uses. The Python app
spawns it and talks over stdio.

Install:  ./install.sh   (installs python, node, atem-connection)
Run:      python autocut.py
"""

__version__ = "1.1.1"

import json, os, queue, shutil, socket, subprocess, sys, threading, time, webbrowser
from shutil import copy as shutil_copy
from dataclasses import dataclass, field, asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import tkinter as tk
from tkinter import ttk, simpledialog, messagebox


BG, PANEL = "#0a0d0c", "#111614"
EDGE, EDGE_BRIGHT = "#1f2926", "#2a3633"
INK, INK_DIM, INK_FAINT = "#d6e2dc", "#7d8a85", "#3d4744"
GREEN, GREEN_DEEP, GREEN_BG = "#3df27d", "#0e6534", "#0a4a25"
AMBER, RED, CYAN, MAGENTA = "#ffb547", "#ff4b3a", "#5ae0e0", "#ff5ac0"

# ── Paths ──────────────────────────────────────────────────────────────
# When running from a PyInstaller .app bundle, resources live in _MEIPASS
# (read-only). User-writable data (config, scenes) goes to a platform-
# appropriate location.
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    BUNDLE_DIR = sys._MEIPASS
else:
    BUNDLE_DIR = os.path.dirname(os.path.abspath(__file__))

if sys.platform == "darwin":
    USER_DATA_DIR = os.path.expanduser("~/Library/Application Support/Autocut")
elif sys.platform == "win32":
    USER_DATA_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Autocut")
else:
    USER_DATA_DIR = os.path.expanduser("~/.config/autocut")
os.makedirs(USER_DATA_DIR, exist_ok=True)

CONFIG_FILE = os.path.join(USER_DATA_DIR, "config.json")
DASHBOARD_HTML_PATH = os.path.join(BUNDLE_DIR, "dashboard.html")
HELPER_JS_PATH = os.path.join(BUNDLE_DIR, "atem-levels.js")


def find_node():
    """Locate the node binary. Priority: bundled inside the .app, then PATH,
    then common locations (Homebrew, nvm). A .app launched from Finder has
    a minimal PATH that usually excludes Homebrew."""
    # Bundled node (set by package.sh for redistributable builds)
    if getattr(sys, "frozen", False):
        # In a PyInstaller .app, sys.executable is .../Contents/MacOS/Autocut
        macos_dir = os.path.dirname(sys.executable)
        bundled = os.path.join(macos_dir, "bundled-node", "node")
        if os.path.isfile(bundled):
            return bundled
    p = shutil.which("node")
    if p: return p
    for cand in ("/opt/homebrew/bin/node",        # Apple Silicon brew
                 "/usr/local/bin/node",            # Intel brew
                 "/usr/bin/node"):
        if os.path.isfile(cand): return cand
    # nvm: pick the newest installed version
    nvm = os.path.expanduser("~/.nvm/versions/node")
    if os.path.isdir(nvm):
        for v in sorted(os.listdir(nvm), reverse=True):
            cand = os.path.join(nvm, v, "bin", "node")
            if os.path.isfile(cand): return cand
    return None

SCENE_FIELDS = [
    "mic1_input", "mic2_input",
    "cam_solo1", "cam_solo2", "cam_both", "cam_extra",
    "mic1_threshold_db", "mic2_threshold_db",
    "mic1_attack_ms",    "mic2_attack_ms",
    "mic1_release_ms",   "mic2_release_ms",
    "both_threshold_db", "both_release_ms",
    "extra_input", "extra_threshold_db",
    "extra_attack_ms", "extra_release_ms",
    "pgm_meter_input",
    "two_cam_mode", "cam_mode",
    "overlap_ms", "min_hold_ms",
]

# Old shared fields → (new mic1 field, new mic2 field) — used for migrating
# pre-per-mic configs and scenes.
LEGACY_FIELD_MAP = [
    ("threshold_db", "mic1_threshold_db", "mic2_threshold_db"),
    ("attack_ms",    "mic1_attack_ms",    "mic2_attack_ms"),
    ("release_ms",   "mic1_release_ms",   "mic2_release_ms"),
]


# ── Config ─────────────────────────────────────────────────────────────
@dataclass
class Config:
    bind_ip: str = "0.0.0.0"
    port: int = 8080
    auto_open: bool = True
    auto_start: bool = False

    atem_ip: str = "192.168.10.240"

    mic1_input: int = 1301
    mic2_input: int = 1302
    cam_solo1: int = 2
    cam_solo2: int = 3
    cam_both: int = 1

    # Per-mic detection
    mic1_threshold_db: float = -38.0
    mic2_threshold_db: float = -38.0
    mic1_attack_ms:    int   = 700
    mic2_attack_ms:    int   = 700
    mic1_release_ms:   int   = 1400
    mic2_release_ms:   int   = 1400

    # BOTH-state detection (when do we commit to / leave the wide shot)
    both_threshold_db: float = -38.0
    both_release_ms:   int   = 1600

    # When true, never cut to the wide/BOTH shot — only SOLO 1 / SOLO 2
    two_cam_mode: bool = False

    # Global timing
    overlap_ms:  int = 2000
    min_hold_ms: int = 800

    enabled: bool = False

    # ── Mode (number of cameras the state machine will use) ──
    # 2 = solo only; 3 = + BOTH; 4 = + extra camera
    cam_mode: int = 3

    # ── Extra camera (mode 4) ──
    cam_extra: int   = 4              # ATEM input number for the 4th cam
    extra_input: int = 1303           # Fairlight audio source id (if any)
    extra_threshold_db: float = -38.0
    extra_attack_ms: int = 700
    extra_release_ms: int = 1400

    # ── PGM channel audio source (which input to meter on the PGM cell) ──
    pgm_meter_input: int = 1301       # which Fairlight source feeds the PGM meter

    # ── UI: theme + waveform palette + cell order/heights ──
    theme: str = "broadcast"          # broadcast | neon | oldpink | blackmagic
    waveform_palette: str = "classic" # classic | mono | theme
    cell_order:  list = field(default_factory=lambda: ["mic1", "pgm", "mic2"])
    cell_heights: dict = field(default_factory=dict)   # cell name -> px
    channels_width: int = 0            # 0 = default; px override for channels column

    # ── ATEM IPs we've successfully connected to (shown in dropdown) ──
    recent_ips: list = field(default_factory=list)

    scenes: dict = field(default_factory=dict)
    active_scene: str = ""

    def save(self):
        try:
            # Back up the previous good config so a bad load is recoverable
            if os.path.exists(CONFIG_FILE):
                try: shutil_copy(CONFIG_FILE, CONFIG_FILE + ".bak")
                except Exception: pass
            with open(CONFIG_FILE, "w") as f:
                json.dump(asdict(self), f, indent=2)
        except Exception as e:
            print("config save failed:", e)

    @classmethod
    def load(cls):
        if not os.path.exists(CONFIG_FILE):
            c = cls()
            c.scenes = {"default": c.snapshot_scene()}
            c.active_scene = "default"
            c.save()
            return c
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            # Migrate legacy shared fields (top-level) into per-mic
            for old, n1, n2 in LEGACY_FIELD_MAP:
                if old in data:
                    data.setdefault(n1, data[old])
                    data.setdefault(n2, data[old])
                    del data[old]
            # Migrate two_cam_mode (bool) → cam_mode (int)
            if "two_cam_mode" in data and "cam_mode" not in data:
                data["cam_mode"] = 2 if data["two_cam_mode"] else 3
            c = cls()
            for k, v in data.items():
                if hasattr(c, k): setattr(c, k, v)
            # Migrate scenes too
            for sname in list(c.scenes.keys()):
                sc = c.scenes[sname]
                if not isinstance(sc, dict): continue
                for old, n1, n2 in LEGACY_FIELD_MAP:
                    if old in sc:
                        sc.setdefault(n1, sc[old])
                        sc.setdefault(n2, sc[old])
                        del sc[old]
            if not c.scenes:
                c.scenes = {"default": c.snapshot_scene()}
                c.active_scene = "default"
            return c
        except Exception:
            return cls()

    def snapshot_scene(self):
        return {k: getattr(self, k) for k in SCENE_FIELDS}

    def apply_scene(self, scene):
        for k, v in scene.items():
            if k in SCENE_FIELDS: setattr(self, k, v)


# ── State machine ──────────────────────────────────────────────────────
class Mic:
    def __init__(self):
        self.db = -90.0
        self.talking = False
        self.above_since = None
        self.below_since = None

    def update(self, db, threshold, attack_ms, release_ms):
        now = time.monotonic() * 1000.0
        self.db = db
        if db >= threshold:
            self.below_since = None
            if self.above_since is None: self.above_since = now
            if not self.talking and (now - self.above_since) >= attack_ms:
                self.talking = True
        else:
            self.above_since = None
            if self.below_since is None: self.below_since = now
            if self.talking and (now - self.below_since) >= release_ms:
                self.talking = False

    def arm_ms(self):
        return int(time.monotonic()*1000 - self.above_since) if self.above_since else 0
    def rel_ms(self):
        return int(time.monotonic()*1000 - self.below_since) if self.below_since else 0


class Engine:
    def __init__(self, cfg, log_cb=None):
        self.cfg = cfg
        self.log_cb = log_cb or (lambda *_: None)
        self.mic1, self.mic2 = Mic(), Mic()
        self.mic_extra = Mic()       # 4th channel detector
        self.both_since = None       # how long both have been above both_threshold
        self.both_below_since = None # how long the wide-shot release has been arming
        self.logical_state = "IDLE"
        self.pending_state = None    # state machine's leaning target (= "preview")
        self.current_program = cfg.cam_solo1
        self.last_cut_at = 0.0
        self.recent_cuts = []
        self.connected = False
        self.labels = {}             # ATEM input id -> name
        self.audio_sources = []      # Fairlight source ids
        self.discovered = []         # discovered ATEM IPs
        self.atem_names = {}         # IP -> mDNS service name

        # Latest levels pushed by the Node helper (dBFS) — keyed by source id
        self._db1 = -90.0
        self._db2 = -90.0
        self._db_pgm = -90.0
        self._db_extra = -90.0
        self._level_lock = threading.Lock()

        # Node helper subprocess
        self._proc = None
        self._reader_thread = None

        self._stop = threading.Event()
        self._thread = None
        self._subs = set()
        self._subs_lock = threading.Lock()

    def subscribe(self):
        q = queue.Queue(maxsize=200)
        with self._subs_lock: self._subs.add(q)
        return q
    def unsubscribe(self, q):
        with self._subs_lock: self._subs.discard(q)
    def client_count(self):
        with self._subs_lock: return len(self._subs)
    def broadcast(self, msg):
        with self._subs_lock: subs = list(self._subs)
        for q in subs:
            try: q.put_nowait(msg)
            except queue.Full: pass

    # ── Node helper management ──
    def _spawn_helper(self):
        node = find_node()
        if not node:
            self.log_cb("Node not found — run install.sh (it installs node)")
            return False
        if not os.path.exists(HELPER_JS_PATH):
            self.log_cb(f"helper missing at {HELPER_JS_PATH}")
            return False
        if self._proc and self._proc.poll() is None:
            return True  # already running
        try:
            self._proc = subprocess.Popen(
                [node, HELPER_JS_PATH],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, bufsize=1,
                cwd=BUNDLE_DIR,
            )
        except Exception as e:
            self.log_cb(f"failed to start helper: {e}")
            return False
        self._reader_thread = threading.Thread(target=self._read_helper, daemon=True)
        self._reader_thread.start()
        self._send_helper({"subscribe": [self.cfg.mic1_input, self.cfg.mic2_input]})
        return True

    def _send_helper(self, obj):
        if not self._proc or self._proc.poll() is not None:
            return
        try:
            self._proc.stdin.write(json.dumps(obj) + "\n")
            self._proc.stdin.flush()
        except Exception as e:
            self.log_cb(f"helper write failed: {e}")

    def _read_helper(self):
        proc = self._proc
        try:
            for line in proc.stdout:
                line = line.strip()
                if not line: continue
                try: msg = json.loads(line)
                except Exception:
                    self.log_cb(f"helper: {line}"); continue
                t = msg.get("type")
                if t == "levels":
                    inp = msg.get("inputs", {})
                    with self._level_lock:
                        if str(self.cfg.mic1_input) in inp:
                            self._db1 = float(inp[str(self.cfg.mic1_input)])
                        if str(self.cfg.mic2_input) in inp:
                            self._db2 = float(inp[str(self.cfg.mic2_input)])
                        if str(self.cfg.extra_input) in inp:
                            self._db_extra = float(inp[str(self.cfg.extra_input)])
                elif t == "master-level":
                    with self._level_lock:
                        try: self._db_pgm = float(msg.get("db", -90.0))
                        except Exception: pass
                elif t == "status":
                    self.connected = bool(msg.get("connected"))
                    self.log_cb("ATEM connected" if self.connected else "ATEM disconnected")
                    self.broadcast({"type":"status","connected":self.connected,
                                    "atemIp":self.cfg.atem_ip,"config":asdict(self.cfg)})
                elif t == "program":
                    self.current_program = int(msg.get("input", self.current_program))
                elif t == "labels":
                    self.labels = msg.get("labels", {}) or {}
                    self.broadcast({"type": "labels", "labels": self.labels})
                elif t == "sources":
                    self.audio_sources = msg.get("ids", []) or []
                    self.broadcast({"type": "sources", "ids": self.audio_sources})
                elif t == "discovered":
                    ip = msg.get("ip")
                    if ip and ip not in self.discovered:
                        self.discovered.append(ip)
                        self.broadcast({"type": "discovered", "ip": ip})
                elif t == "discoverDone":
                    self.broadcast({"type": "discoverDone", "list": self.discovered})
                elif t == "log":
                    line = "helper: " + str(msg.get("msg", ""))
                    self.log_cb(line)
                    self.broadcast({"type": "log", "msg": line})
        except Exception:
            pass

    def connect_atem(self, ip):
        self.cfg.atem_ip = ip
        # remember this IP, most-recent first, cap at 8
        try:
            ips = [x for x in (self.cfg.recent_ips or []) if x != ip]
            ips.insert(0, ip)
            self.cfg.recent_ips = ips[:8]
        except Exception:
            self.cfg.recent_ips = [ip]
        self.cfg.save()
        if not self._spawn_helper():
            return
        self.log_cb(f"ATEM connecting to {ip}…")
        self._send_helper({"connect": ip})

    def disconnect_atem(self):
        if self._proc and self._proc.poll() is None:
            try: self._proc.terminate()
            except Exception: pass
        self._proc = None
        self.connected = False

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
    def stop(self):
        self._stop.set(); self.disconnect_atem()

    def _loop(self):
        while not self._stop.is_set():
            t0 = time.monotonic()
            with self._level_lock:
                if self.connected:
                    db1, db2, dbE, dbP = self._db1, self._db2, self._db_extra, self._db_pgm
                else:
                    db1 = db2 = dbE = dbP = -90.0

            self.mic1.update(db1, self.cfg.mic1_threshold_db,
                                  self.cfg.mic1_attack_ms,
                                  self.cfg.mic1_release_ms)
            self.mic2.update(db2, self.cfg.mic2_threshold_db,
                                  self.cfg.mic2_attack_ms,
                                  self.cfg.mic2_release_ms)
            self.mic_extra.update(dbE, self.cfg.extra_threshold_db,
                                       self.cfg.extra_attack_ms,
                                       self.cfg.extra_release_ms)
            self._evaluate(db1, db2)
            pending_cam = {"SOLO_1": self.cfg.cam_solo1, "SOLO_2": self.cfg.cam_solo2,
                           "BOTH":   self.cfg.cam_both,  "SOLO_EXTRA": self.cfg.cam_extra
                          }.get(self.pending_state)
            self.broadcast({
                "type": "tick",
                "mic1Db": db1, "mic2Db": db2, "extraDb": dbE, "pgmDb": dbP,
                "mic1Talking": self.mic1.talking, "mic2Talking": self.mic2.talking,
                "extraTalking": self.mic_extra.talking,
                "mic1Arm": self.mic1.arm_ms(), "mic2Arm": self.mic2.arm_ms(),
                "extraArm": self.mic_extra.arm_ms(),
                "mic1Rel": self.mic1.rel_ms(), "mic2Rel": self.mic2.rel_ms(),
                "extraRel": self.mic_extra.rel_ms(),
                "bothArm": int(time.monotonic()*1000 - self.both_since) if self.both_since else 0,
                "state": self.logical_state, "program": self.current_program,
                "pending": self.pending_state, "preview": pending_cam,
            })
            time.sleep(max(0, 0.033 - (time.monotonic() - t0)))

    def _evaluate(self, db1, db2):
        now = time.monotonic() * 1000.0
        m1, m2 = self.mic1.talking, self.mic2.talking

        # BOTH decision: only when mode 3 or 4 (mode 2 = solo only).
        both_enabled = (self.cfg.cam_mode in (3, 4))
        both_now = (both_enabled and
                    db1 >= self.cfg.both_threshold_db and
                    db2 >= self.cfg.both_threshold_db)

        desired = self.logical_state

        if both_now:
            self.both_below_since = None
            if self.both_since is None: self.both_since = now
            if (now - self.both_since) >= self.cfg.overlap_ms:
                desired = "BOTH"
            else:
                # Both mics are talking but the overlap window hasn't elapsed yet.
                # Pick a solo so we still cut something instead of getting stuck.
                if self.logical_state in ("SOLO_1", "SOLO_2"):
                    pass  # keep current solo while we arm BOTH
                elif m1 and not m2: desired = "SOLO_1"
                elif m2 and not m1: desired = "SOLO_2"
                else:
                    # Both true, no prior solo — pick the louder one
                    desired = "SOLO_1" if db1 >= db2 else "SOLO_2"
        else:
            self.both_since = None
            if self.logical_state == "BOTH":
                # leave the wide shot only after both_release of not-both
                if self.both_below_since is None: self.both_below_since = now
                if (now - self.both_below_since) >= self.cfg.both_release_ms:
                    if m1 and not m2: desired = "SOLO_1"
                    elif m2 and not m1: desired = "SOLO_2"
                    elif m1 and m2: desired = "BOTH"
                    else: desired = "SOLO_1" if self.current_program == self.cfg.cam_solo1 else self.logical_state
                # else: hold BOTH during the release window
            else:
                self.both_below_since = None
                if m1 and not m2: desired = "SOLO_1"
                elif m2 and not m1: desired = "SOLO_2"
                elif m1 and m2:
                    # both talking but not loud enough for BOTH gate — pick louder
                    desired = "SOLO_1" if db1 >= db2 else "SOLO_2"
                # 4-cam: extra mic takes program when only it is talking
                if self.cfg.cam_mode == 4 and self.mic_extra.talking and not m1 and not m2:
                    desired = "SOLO_EXTRA"

        # pending = what we're leaning toward (drives "preview" colour)
        self.pending_state = desired

        if not self.cfg.enabled:
            self.logical_state = desired; return
        if desired == self.logical_state: return
        if (now - self.last_cut_at) < self.cfg.min_hold_ms: return
        cam_map = {"SOLO_1": self.cfg.cam_solo1, "SOLO_2": self.cfg.cam_solo2,
                   "BOTH":   self.cfg.cam_both,  "SOLO_EXTRA": self.cfg.cam_extra}
        target = cam_map.get(desired)
        if target and target != self.current_program:
            self._cut_to(target, desired)
        self.logical_state = desired

    def cut_to(self, n, reason="manual"):
        self._cut_to(n, reason)

    def _cut_to(self, input_num, reason):
        if not self.connected:
            self.log_cb(f"cut ignored ({reason}): ATEM not connected"); return
        self._send_helper({"cut": int(input_num)})
        frm = self.current_program
        self.current_program = input_num
        self.last_cut_at = time.monotonic() * 1000.0
        entry = {"ts": time.time(), "from": frm, "to": input_num, "reason": reason}
        self.recent_cuts.insert(0, entry); del self.recent_cuts[30:]
        self.broadcast({"type":"cut", **entry})
        self.log_cb(f"cut {frm} → {input_num} ({reason})")

    def discover(self):
        """Discover ATEMs on the local network via mDNS/Bonjour. ATEMs publish
        themselves under _blackmagic._tcp.local. (the same record Finder reads).
        Runs in a background thread; broadcasts each find via SSE."""
        self.discovered = []
        threading.Thread(target=self._mdns_scan, daemon=True).start()

    def _mdns_scan(self):
        try:
            from zeroconf import Zeroconf, ServiceBrowser, ServiceListener
        except ImportError:
            self.log_cb("zeroconf not installed — run install.sh to add it")
            self.broadcast({"type": "discoverDone", "list": []})
            return

        found = {}
        engine = self

        def handle_info(type_, name, info):
            try:
                ip = ".".join(str(b) for b in info.addresses[0]) if info.addresses else None
                if not ip: return
                # Extract a friendly name. Service names look like:
                #   "ATEM Mini Pro ISO._blackmagic._tcp.local."
                # but SMB services may be "djchemic-mac._smb._tcp.local."
                nice = name.split("._")[0] if "._" in name else name.split(".")[0]
                # If the name is opaque (e.g. just MAC bytes), try the server/hostname
                if info.server:
                    server = info.server.rstrip(".")
                    if server.endswith(".local"):
                        server = server[:-6]
                    # Prefer a longer/clearer hostname if "nice" is just numbers/dashes
                    if (not nice) or (nice.replace("-", "").replace(":", "").isalnum() and "atem" not in nice.lower() and "atem" in server.lower()):
                        nice = server
                found[ip] = nice
                if ip not in engine.discovered:
                    engine.discovered.append(ip)
                engine.log_cb(f"mDNS: found '{nice}' at {ip} via {type_}")
                engine.broadcast({"type": "discovered", "ip": ip, "name": nice})
            except Exception as e:
                engine.log_cb(f"mDNS handle_info error: {e}")

        class AtemListener(ServiceListener):
            def __init__(self, zc): self.zc = zc
            def add_service(self, zc, type_, name):
                try:
                    info = zc.get_service_info(type_, name, timeout=1500)
                    if info: handle_info(type_, name, info)
                except Exception: pass
            def update_service(self, zc, type_, name):
                try:
                    info = zc.get_service_info(type_, name, timeout=1500)
                    if info: handle_info(type_, name, info)
                except Exception: pass
            def remove_service(self, *a, **kw): pass

        # ATEMs may publish under several service types depending on firmware.
        # Cast a wide net.
        service_types = [
            "_blackmagic._tcp.local.",
            "_atem._tcp.local.",
            "_blackmagic-mixer._tcp.local.",
            "_bmd-atem-control._tcp.local.",
            "_smb._tcp.local.",        # ATEMs publish SMB for USB-disk sharing
        ]
        try:
            zc = Zeroconf()
            listener = AtemListener(zc)
            for st in service_types:
                try: ServiceBrowser(zc, st, listener)
                except Exception as e: self.log_cb(f"mDNS browser {st} error: {e}")
            self.log_cb(f"mDNS: scanning for ATEMs across {len(service_types)} service types...")
            time.sleep(4.0)  # listen briefly for replies
            zc.close()
        except Exception as e:
            self.log_cb(f"mDNS scan error: {e}")
        # Keep ALL discovered devices — let the user decide.
        # The dashboard already showed each name via the live "discovered" broadcast.
        self.atem_names = dict(found)
        # Diagnostic: log what was actually found, with names
        if found:
            for ip, nm in found.items():
                self.log_cb(f"mDNS result: {ip} → '{nm}'")
        else:
            self.log_cb("mDNS: no devices found on the network")
        self.log_cb(f"mDNS scan done: {len(self.atem_names)} devices total")
        self.broadcast({"type": "discoverDone", "list": self.discovered, "names": self.atem_names})

    def push_config(self):
        # keep the helper watching the currently-selected mic inputs + pgm-meter + extra
        subs = list({self.cfg.mic1_input, self.cfg.mic2_input,
                     self.cfg.pgm_meter_input, self.cfg.extra_input})
        self._send_helper({"subscribe": subs})
        self.broadcast({"type":"config","config":asdict(self.cfg),
                        "activeScene":self.cfg.active_scene,
                        "scenes":list(self.cfg.scenes.keys())})


# ── HTTP server ────────────────────────────────────────────────────────
def build_handler(engine, html_provider):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a, **k): pass

        def _headers(self, code, ctype, length=None, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            if length is not None: self.send_header("Content-Length", str(length))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            for k, v in (extra or {}).items(): self.send_header(k, v)
            self.end_headers()

        def _json(self, code, payload):
            body = json.dumps(payload).encode()
            self._headers(code, "application/json", len(body))
            try: self.wfile.write(body)
            except Exception: pass

        def _body(self):
            n = int(self.headers.get("Content-Length", "0") or 0)
            if not n: return {}
            try: return json.loads(self.rfile.read(n))
            except Exception: return {}

        def do_OPTIONS(self): self._headers(204, "text/plain", 0)

        def do_GET(self):
            p = self.path.split("?", 1)[0]
            if p in ("/", "/index.html", "/dashboard.html"):
                data = html_provider().encode("utf-8")
                self._headers(200, "text/html; charset=utf-8", len(data))
                try: self.wfile.write(data)
                except Exception: pass
                return
            if p == "/favicon.png":
                fav = os.path.join(BUNDLE_DIR, "favicon.png")
                try:
                    with open(fav, "rb") as f: data = f.read()
                    self._headers(200, "image/png", len(data))
                    self.wfile.write(data)
                except Exception:
                    self._headers(404, "text/plain", 0)
                return
            if p == "/api/status":
                return self._json(200, {
                    "enabled": engine.cfg.enabled, "connected": engine.connected,
                    "program": engine.current_program, "state": engine.logical_state,
                    "atemIp": engine.cfg.atem_ip,
                    "mic1Db": engine.mic1.db, "mic2Db": engine.mic2.db,
                    "config": asdict(engine.cfg),
                    "activeScene": engine.cfg.active_scene,
                    "scenes": list(engine.cfg.scenes.keys()),
                    "labels": engine.labels,
                    "discovered": engine.discovered,
                    "atemNames": engine.atem_names,
                })
            if p == "/api/scenes":
                return self._json(200, {"scenes": engine.cfg.scenes,
                                        "active": engine.cfg.active_scene})
            if p == "/api/events":
                return self._sse()
            return self._json(404, {"error":"not found"})

        def _sse(self):
            self._headers(200, "text/event-stream",
                          extra={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})
            q = engine.subscribe()
            try:
                self.wfile.write(("data: " + json.dumps({
                    "type":"status","connected":engine.connected,
                    "atemIp":engine.cfg.atem_ip,"config":asdict(engine.cfg),
                    "activeScene":engine.cfg.active_scene,
                    "scenes":list(engine.cfg.scenes.keys()),
                }) + "\n\n").encode())
                self.wfile.flush()
            except Exception:
                engine.unsubscribe(q); return
            try:
                while True:
                    try: msg = q.get(timeout=15)
                    except queue.Empty:
                        self.wfile.write(b": ping\n\n"); self.wfile.flush(); continue
                    self.wfile.write(("data: " + json.dumps(msg) + "\n\n").encode())
                    self.wfile.flush()
            except Exception: pass
            finally: engine.unsubscribe(q)

        def do_POST(self):
            cfg = engine.cfg
            p = self.path.split("?", 1)[0]
            if p == "/api/enable":  cfg.enabled = True;  cfg.save(); return self._json(200, {"ok":True})
            if p == "/api/disable": cfg.enabled = False; cfg.save(); return self._json(200, {"ok":True})
            if p == "/api/toggle":
                cfg.enabled = not cfg.enabled; cfg.save()
                return self._json(200, {"ok":True,"enabled":cfg.enabled})
            if p == "/api/connect":
                body = self._body(); ip = (body.get("ip") or "").strip()
                if not ip: return self._json(400, {"error":"ip required"})
                engine.connect_atem(ip); return self._json(200, {"ok":True})
            if p == "/api/force":
                body = self._body()
                try: n = int(body.get("input"))
                except Exception: return self._json(400, {"error":"input required"})
                engine.cut_to(n, "companion"); return self._json(200, {"ok":True})
            if p == "/api/discover":
                engine.discover(); return self._json(200, {"ok":True})
            if p == "/api/config":
                body = self._body()
                aliases = {
                    "overlapMs":"overlap_ms", "minHoldMs":"min_hold_ms",
                    "mic1Input":"mic1_input", "mic2Input":"mic2_input",
                    "camSolo1":"cam_solo1",   "camSolo2":"cam_solo2", "camBoth":"cam_both",
                    "mic1ThresholdDb":"mic1_threshold_db",
                    "mic2ThresholdDb":"mic2_threshold_db",
                    "mic1AttackMs":"mic1_attack_ms",
                    "mic2AttackMs":"mic2_attack_ms",
                    "mic1ReleaseMs":"mic1_release_ms",
                    "mic2ReleaseMs":"mic2_release_ms",
                }
                for k, v in body.items():
                    real = aliases.get(k, k)
                    if real == "two_cam_mode" and isinstance(v, bool):
                        cfg.cam_mode = 2 if v else 3
                    elif real == "cam_mode" and isinstance(v, int):
                        cfg.cam_mode = max(2, min(4, v))
                    elif real == "theme" and isinstance(v, str):
                        cfg.theme = v
                    elif real == "waveform_palette" and isinstance(v, str):
                        cfg.waveform_palette = v
                    elif real == "channels_width" and isinstance(v, (int, float)):
                        cfg.channels_width = max(0, int(v))
                    elif real == "cell_order" and isinstance(v, list):
                        cfg.cell_order = [str(x) for x in v]
                    elif real == "cell_heights" and isinstance(v, dict):
                        cfg.cell_heights = {str(k2): int(v2) for k2, v2 in v.items() if isinstance(v2,(int,float))}
                    elif real in SCENE_FIELDS and isinstance(v, (int, float)) and not isinstance(v, bool):
                        setattr(cfg, real, v)
                cfg.save(); engine.push_config()
                return self._json(200, {"ok":True,"config":asdict(cfg)})
            if p == "/api/scenes/save":
                body = self._body(); name = (body.get("name") or "").strip()
                if not name: return self._json(400, {"error":"name required"})
                cfg.scenes[name] = cfg.snapshot_scene()
                cfg.active_scene = name; cfg.save(); engine.push_config()
                return self._json(200, {"ok":True,"name":name})
            if p == "/api/scenes/load":
                body = self._body(); name = (body.get("name") or "").strip()
                if name not in cfg.scenes: return self._json(404, {"error":"scene not found"})
                cfg.apply_scene(cfg.scenes[name]); cfg.active_scene = name
                cfg.save(); engine.push_config()
                return self._json(200, {"ok":True,"name":name,"config":asdict(cfg)})
            if p == "/api/scenes/delete":
                body = self._body(); name = (body.get("name") or "").strip()
                if name in cfg.scenes:
                    del cfg.scenes[name]
                    if cfg.active_scene == name: cfg.active_scene = ""
                    cfg.save(); engine.push_config()
                return self._json(200, {"ok":True})
            if p == "/api/scenes/rename":
                body = self._body()
                old = (body.get("from") or "").strip()
                new = (body.get("to") or "").strip()
                if old not in cfg.scenes: return self._json(404, {"error":"scene not found"})
                if not new: return self._json(400, {"error":"new name required"})
                cfg.scenes[new] = cfg.scenes.pop(old)
                if cfg.active_scene == old: cfg.active_scene = new
                cfg.save(); engine.push_config()
                return self._json(200, {"ok":True})
            return self._json(404, {"error":"not found"})
    return H


class Server:
    def __init__(self, engine, html_provider, log_cb):
        self.engine = engine; self.html_provider = html_provider
        self.log_cb = log_cb; self.httpd = None; self.thread = None

    def start(self, bind_ip, port):
        Handler = build_handler(self.engine, self.html_provider)
        try: self.httpd = ThreadingHTTPServer((bind_ip, port), Handler)
        except OSError as e:
            self.log_cb(f"server start failed: {e}"); return False
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start(); self.engine.start()
        self.log_cb(f"server listening on {bind_ip}:{port}")
        return True

    def stop(self):
        if self.httpd:
            try: self.httpd.shutdown(); self.httpd.server_close()
            except Exception: pass
            self.httpd = None; self.log_cb("server stopped")
        self.engine.stop()


def discover_ips():
    ips = {"0.0.0.0", "127.0.0.1"}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ips.add(s.getsockname()[0]); s.close()
    except Exception: pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except Exception: pass
    real = sorted(i for i in ips if i not in ("0.0.0.0", "127.0.0.1"))
    return ["0.0.0.0"] + real + ["127.0.0.1"]


def load_html():
    try:
        with open(DASHBOARD_HTML_PATH) as f: return f.read()
    except FileNotFoundError:
        return ("<html><body style='background:#0a0d0c;color:#d6e2dc;"
                "font-family:monospace;padding:40px'>"
                "<h2>dashboard.html missing</h2>"
                f"<p>Place <code>dashboard.html</code> next to <code>autocut.py</code> "
                f"at <code>{DASHBOARD_HTML_PATH}</code></p></body></html>")


# ── Launcher window ───────────────────────────────────────────────────
class Launcher:
    def __init__(self, root):
        self.root = root
        self.cfg = Config.load()
        self.engine = Engine(self.cfg, log_cb=self.log)
        self.server = Server(self.engine, load_html, log_cb=self.log)
        self.running = False
        self._build_ui()
        self._refresh_status_loop()
        if self.cfg.auto_start:
            self.root.after(200, self._start_server)
        if self.cfg.atem_ip:
            self.root.after(500, lambda: self.engine.connect_atem(self.cfg.atem_ip))
        # mDNS scan for ATEMs on the network (real Bonjour discovery)
        self.root.after(800, self.engine.discover)

    def _style(self):
        st = ttk.Style()
        try: st.theme_use("clam")
        except Exception: pass
        st.configure(".", background=BG, foreground=INK, fieldbackground="#06090a",
                     borderwidth=0, relief="flat")
        st.configure("TFrame", background=BG)
        st.configure("TLabel", background=BG, foreground=INK)
        st.configure("TButton", background="#0c1311", foreground=INK,
                     bordercolor=EDGE_BRIGHT, focusthickness=0, padding=(10, 6),
                     font=("Helvetica Neue", 9, "bold"))
        st.map("TButton", background=[("active", "#162019")])
        st.configure("Primary.TButton", background=GREEN_BG, foreground="#bff5d2",
                     bordercolor=GREEN_DEEP, padding=(14, 10),
                     font=("Helvetica Neue", 11, "bold"))
        st.map("Primary.TButton", background=[("active", GREEN_DEEP)])
        st.configure("Danger.TButton", background="#3a0f0c", foreground="#ffc7c2",
                     bordercolor="#5a1a14", padding=(14, 10),
                     font=("Helvetica Neue", 11, "bold"))
        st.configure("Small.TButton", padding=(8, 4),
                     font=("Helvetica Neue", 9, "bold"))
        st.configure("TEntry", fieldbackground="#06090a", foreground=INK,
                     bordercolor=EDGE, insertcolor=INK, padding=6)
        st.configure("TCombobox", fieldbackground="#06090a", foreground=INK,
                     background="#0c1311", arrowcolor=INK_DIM, bordercolor=EDGE)
        st.configure("TCheckbutton", background=PANEL, foreground=INK_DIM,
                     focusthickness=0)
        st.map("TCheckbutton", background=[("active", PANEL)])

    def _build_ui(self):
        r = self.root
        r.title("autocut · launcher")
        r.configure(bg=BG); r.geometry("560x820"); r.minsize(540, 780)
        self._style()

        # Header
        header = tk.Frame(r, bg=BG, height=60); header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="● AUTOCUT", bg=BG, fg=GREEN,
                 font=("Helvetica Neue", 15, "bold")).pack(side="left", padx=(20, 6), pady=16)
        tk.Label(header, text="// ATEM mini pro iso", bg=BG, fg=INK_FAINT,
                 font=("Helvetica Neue", 10)).pack(side="left", pady=16)

        self._server_card(r)
        action = tk.Frame(r, bg=BG); action.pack(fill="x", padx=20, pady=(0, 10))
        self.start_btn = ttk.Button(action, text="START SERVER",
                                    style="Primary.TButton", command=self._toggle_server)
        self.start_btn.pack(fill="x")
        self.url_card = self._url_card(r)
        self._status_card(r)
        self._scenes_card(r)
        self._appearance_card(r)
        self._log_card(r)

        self.log(f"autocut v{__version__} launcher ready")
        if find_node() is None:
            self.log("WARNING: node not found — run install.sh (installs node)")
        elif not os.path.exists(HELPER_JS_PATH):
            self.log(f"WARNING: atem-levels.js missing at {HELPER_JS_PATH}")

    def _card(self, parent, title):
        outer = tk.Frame(parent, bg=PANEL, highlightbackground=EDGE, highlightthickness=1)
        outer.pack(fill="x", padx=20, pady=(0, 10))
        tk.Label(outer, text=title, bg=PANEL, fg=INK_FAINT,
                 font=("Helvetica Neue", 9, "bold")).pack(anchor="w", padx=16, pady=(14, 6))
        return outer

    def _server_card(self, parent):
        card = self._card(parent, "SERVER CONFIGURATION")
        row = tk.Frame(card, bg=PANEL); row.pack(fill="x", padx=16, pady=2)
        tk.Label(row, text="BIND TO", bg=PANEL, fg=INK_DIM, width=14, anchor="w",
                 font=("Helvetica Neue", 9, "bold")).pack(side="left")
        self.ip_var = tk.StringVar(value=self.cfg.bind_ip)
        ttk.Combobox(row, textvariable=self.ip_var, values=discover_ips(),
                     font=("Menlo", 11), width=22).pack(side="left", fill="x", expand=True, padx=8)

        row2 = tk.Frame(card, bg=PANEL); row2.pack(fill="x", padx=16, pady=6)
        tk.Label(row2, text="PORT", bg=PANEL, fg=INK_DIM, width=14, anchor="w",
                 font=("Helvetica Neue", 9, "bold")).pack(side="left")
        self.port_var = tk.StringVar(value=str(self.cfg.port))
        ttk.Entry(row2, textvariable=self.port_var, font=("Menlo", 11), width=10).pack(side="left", padx=8)

        opts = tk.Frame(card, bg=PANEL); opts.pack(fill="x", padx=16, pady=(4, 12))
        self.auto_open_var = tk.BooleanVar(value=self.cfg.auto_open)
        ttk.Checkbutton(opts, text="Auto-open browser on start",
                        variable=self.auto_open_var,
                        command=lambda: self._set_cfg("auto_open", self.auto_open_var.get())
                       ).pack(anchor="w")
        self.auto_start_var = tk.BooleanVar(value=self.cfg.auto_start)
        ttk.Checkbutton(opts, text="Start server automatically when launcher opens",
                        variable=self.auto_start_var,
                        command=lambda: self._set_cfg("auto_start", self.auto_start_var.get())
                       ).pack(anchor="w")

    def _url_card(self, parent):
        card = tk.Frame(parent, bg=PANEL, highlightbackground=EDGE, highlightthickness=1)
        tk.Label(card, text="DASHBOARD URL", bg=PANEL, fg=INK_FAINT,
                 font=("Helvetica Neue", 9, "bold")).pack(anchor="w", padx=16, pady=(14, 4))
        self.url_lbl = tk.Label(card, text="—", bg=PANEL, fg=GREEN,
                                font=("Menlo", 14, "bold"))
        self.url_lbl.pack(anchor="w", padx=16, pady=(0, 8))
        btns = tk.Frame(card, bg=PANEL); btns.pack(fill="x", padx=16, pady=(0, 14))
        ttk.Button(btns, text="LAUNCH GUI", style="Primary.TButton",
                   command=self._open_browser).pack(side="left")
        ttk.Button(btns, text="COPY URL", command=self._copy_url).pack(side="left", padx=8)
        return card

    def _status_card(self, parent):
        card = self._card(parent, "STATUS")
        grid = tk.Frame(card, bg=PANEL); grid.pack(fill="x", padx=16, pady=(0, 14))
        self.srv_dot  = self._status_row(grid, "SERVER",  0)
        self.atem_dot = self._status_row(grid, "ATEM",    1)
        self.auto_dot = self._status_row(grid, "AUTO",    2)
        self.cli_dot  = self._status_row(grid, "CLIENTS", 3)
        self.sc_dot   = self._status_row(grid, "SCENE",   4)

    def _status_row(self, parent, label, row):
        tk.Label(parent, text=label, bg=PANEL, fg=INK_DIM, anchor="w",
                 font=("Helvetica Neue", 9, "bold"), width=12
                ).grid(row=row, column=0, sticky="w", pady=2)
        dot = tk.Label(parent, text="●", bg=PANEL, fg=INK_FAINT, font=("Menlo", 11))
        dot.grid(row=row, column=1, sticky="w", padx=(0, 6))
        val = tk.Label(parent, text="—", bg=PANEL, fg=INK_DIM, font=("Menlo", 10))
        val.grid(row=row, column=2, sticky="w")
        return (dot, val)

    def _scenes_card(self, parent):
        card = self._card(parent, "SCENES · per-podcast presets")
        body = tk.Frame(card, bg=PANEL); body.pack(fill="x", padx=16, pady=(2, 12))

        list_wrap = tk.Frame(body, bg="#06090a", highlightbackground=EDGE, highlightthickness=1)
        list_wrap.pack(fill="x")
        self.scene_list = tk.Listbox(list_wrap, bg="#06090a", fg=INK,
                                     selectbackground=GREEN_BG, selectforeground="#bff5d2",
                                     activestyle="none", borderwidth=0,
                                     highlightthickness=0, font=("Menlo", 11),
                                     height=5)
        self.scene_list.pack(fill="x", padx=2, pady=2)
        self.scene_list.bind("<Double-Button-1>", lambda e: self._scene_load())
        self._refresh_scenes()

        btns = tk.Frame(body, bg=PANEL); btns.pack(fill="x", pady=(8, 0))
        ttk.Button(btns, text="LOAD",     style="Small.TButton", command=self._scene_load   ).pack(side="left")
        ttk.Button(btns, text="SAVE AS…", style="Small.TButton", command=self._scene_save_as).pack(side="left", padx=6)
        ttk.Button(btns, text="UPDATE",   style="Small.TButton", command=self._scene_update ).pack(side="left", padx=6)
        ttk.Button(btns, text="RENAME",   style="Small.TButton", command=self._scene_rename ).pack(side="left", padx=6)
        ttk.Button(btns, text="DELETE",   style="Small.TButton", command=self._scene_delete ).pack(side="right")

    def _appearance_card(self, parent):
        card = self._card(parent, "APPEARANCE")
        body = tk.Frame(card, bg=PANEL); body.pack(fill="x", padx=16, pady=(0, 12))

        # Theme row
        tk.Label(body, text="THEME", bg=PANEL, fg=INK_DIM, anchor="w",
                 font=("Helvetica Neue", 9, "bold")).pack(anchor="w", pady=(2,4))
        theme_row = tk.Frame(body, bg=PANEL); theme_row.pack(fill="x")
        self._theme_btns = {}
        for code, label in (("broadcast","Broadcast"), ("neon","Neon"),
                            ("oldpink","Old Pink"), ("blackmagic","Blackmagic")):
            b = ttk.Button(theme_row, text=label, style="Small.TButton",
                           command=lambda c=code: self._set_theme(c))
            b.pack(side="left", padx=2, fill="x", expand=True)
            self._theme_btns[code] = b
        self._update_theme_active()

        # Waveform palette row
        tk.Label(body, text="WAVEFORM COLORS", bg=PANEL, fg=INK_DIM, anchor="w",
                 font=("Helvetica Neue", 9, "bold")).pack(anchor="w", pady=(12,4))
        wf_row = tk.Frame(body, bg=PANEL); wf_row.pack(fill="x")
        self._wf_btns = {}
        for code, label in (("classic","Classic G/Y/R"),
                            ("mono","Monochrome"),
                            ("theme","Match Theme")):
            b = ttk.Button(wf_row, text=label, style="Small.TButton",
                           command=lambda c=code: self._set_palette(c))
            b.pack(side="left", padx=2, fill="x", expand=True)
            self._wf_btns[code] = b
        self._update_wf_active()

    def _set_theme(self, code):
        self.cfg.theme = code
        self.cfg.save()
        self.engine.push_config()
        self._update_theme_active()
        self.log(f"theme: {code}")

    def _set_palette(self, code):
        self.cfg.waveform_palette = code
        self.cfg.save()
        self.engine.push_config()
        self._update_wf_active()
        self.log(f"waveform palette: {code}")

    def _update_theme_active(self):
        if not hasattr(self, "_theme_btns"): return
        for code, b in self._theme_btns.items():
            b.configure(style="Primary.TButton" if code == self.cfg.theme else "Small.TButton")

    def _update_wf_active(self):
        if not hasattr(self, "_wf_btns"): return
        for code, b in self._wf_btns.items():
            b.configure(style="Primary.TButton" if code == self.cfg.waveform_palette else "Small.TButton")

    def _log_card(self, parent):
        card = tk.Frame(parent, bg=PANEL, highlightbackground=EDGE, highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=(0, 16))
        tk.Label(card, text="LOG", bg=PANEL, fg=INK_FAINT,
                 font=("Helvetica Neue", 9, "bold")).pack(anchor="w", padx=16, pady=(14, 4))
        wrap = tk.Frame(card, bg="#06090a")
        wrap.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        self.log_text = tk.Text(wrap, bg="#06090a", fg=INK_DIM,
                                font=("Menlo", 9), borderwidth=0, relief="flat",
                                insertbackground=INK, padx=8, pady=6, height=6)
        self.log_text.pack(fill="both", expand=True)
        self.log_text.config(state="disabled")

    def _refresh_scenes(self):
        names = list(self.cfg.scenes.keys())
        self.scene_list.delete(0, "end")
        active = self.cfg.active_scene
        for n in names:
            label = ("●  " + n) if n == active else ("    " + n)
            self.scene_list.insert("end", label)
        if active in names:
            idx = names.index(active)
            self.scene_list.selection_clear(0, "end")
            self.scene_list.selection_set(idx); self.scene_list.activate(idx)

    def _selected_scene(self):
        sel = self.scene_list.curselection()
        if not sel: return None
        return self.scene_list.get(sel[0]).lstrip("● ").strip()

    def _scene_load(self):
        name = self._selected_scene()
        if not name or name not in self.cfg.scenes: return
        self.cfg.apply_scene(self.cfg.scenes[name])
        self.cfg.active_scene = name; self.cfg.save()
        self.engine.push_config(); self._refresh_scenes()
        self.log(f"loaded scene '{name}'")

    def _scene_save_as(self):
        name = simpledialog.askstring("Save scene", "Scene name:", parent=self.root)
        if not name: return
        name = name.strip()
        if not name: return
        if name in self.cfg.scenes and not messagebox.askyesno(
                "Overwrite?", f"Scene '{name}' exists. Overwrite?"):
            return
        self.cfg.scenes[name] = self.cfg.snapshot_scene()
        self.cfg.active_scene = name; self.cfg.save()
        self.engine.push_config(); self._refresh_scenes()
        self.log(f"saved scene '{name}'")

    def _scene_update(self):
        name = self._selected_scene()
        if not name: return
        self.cfg.scenes[name] = self.cfg.snapshot_scene()
        self.cfg.active_scene = name; self.cfg.save()
        self.engine.push_config(); self._refresh_scenes()
        self.log(f"updated scene '{name}'")

    def _scene_rename(self):
        old = self._selected_scene()
        if not old: return
        new = simpledialog.askstring("Rename scene", "New name:", initialvalue=old, parent=self.root)
        if not new: return
        new = new.strip()
        if not new or new == old: return
        if new in self.cfg.scenes:
            messagebox.showerror("Exists", f"Scene '{new}' already exists."); return
        self.cfg.scenes[new] = self.cfg.scenes.pop(old)
        if self.cfg.active_scene == old: self.cfg.active_scene = new
        self.cfg.save(); self.engine.push_config(); self._refresh_scenes()
        self.log(f"renamed '{old}' → '{new}'")

    def _scene_delete(self):
        name = self._selected_scene()
        if not name: return
        if not messagebox.askyesno("Delete scene", f"Delete scene '{name}'?"): return
        if name in self.cfg.scenes: del self.cfg.scenes[name]
        if self.cfg.active_scene == name: self.cfg.active_scene = ""
        self.cfg.save(); self.engine.push_config(); self._refresh_scenes()
        self.log(f"deleted scene '{name}'")

    def _refresh_status_loop(self):
        srv_on = self.running
        atem_on = self.engine.connected
        auto_on = self.cfg.enabled
        clients = self.engine.client_count()
        scene = self.cfg.active_scene or "(none)"

        self.srv_dot[0].config(fg=GREEN if srv_on else INK_FAINT)
        self.srv_dot[1].config(text="running" if srv_on else "stopped",
                                fg=INK if srv_on else INK_DIM)
        self.atem_dot[0].config(fg=GREEN if atem_on else (AMBER if srv_on else INK_FAINT))
        self.atem_dot[1].config(text=self.cfg.atem_ip if atem_on else "disconnected",
                                 fg=INK if atem_on else INK_DIM)
        self.auto_dot[0].config(fg=GREEN if auto_on else INK_FAINT)
        self.auto_dot[1].config(text="enabled" if auto_on else "disabled",
                                 fg=INK if auto_on else INK_DIM)
        self.cli_dot[0].config(fg=CYAN if clients else INK_FAINT)
        self.cli_dot[1].config(text=str(clients), fg=INK if clients else INK_DIM)
        self.sc_dot[0].config(fg=MAGENTA if self.cfg.active_scene else INK_FAINT)
        self.sc_dot[1].config(text=scene, fg=INK if self.cfg.active_scene else INK_DIM)

        if self.scene_list.size() != len(self.cfg.scenes):
            self._refresh_scenes()
        self.root.after(500, self._refresh_status_loop)

    def _toggle_server(self):
        if self.running: self._stop_server()
        else: self._start_server()

    def _start_server(self):
        ip = self.ip_var.get().strip() or "0.0.0.0"
        try: port = int(self.port_var.get().strip())
        except Exception: self.log("invalid port"); return
        self.cfg.bind_ip = ip; self.cfg.port = port; self.cfg.save()
        if not self.server.start(ip, port): return
        self.running = True
        self.start_btn.config(text="STOP SERVER", style="Danger.TButton")
        self.url_lbl.config(text=self._url())
        self.url_card.pack(fill="x", padx=20, pady=(0, 10), after=self.start_btn.master)
        if self.cfg.auto_open:
            self.root.after(400, lambda: webbrowser.open(self._url()))

    def _stop_server(self):
        self.server.stop(); self.running = False
        self.start_btn.config(text="START SERVER", style="Primary.TButton")
        self.url_card.pack_forget()

    def _url(self):
        ip = self.cfg.bind_ip
        display = "localhost" if ip in ("0.0.0.0", "127.0.0.1") else ip
        return f"http://{display}:{self.cfg.port}"

    def _open_browser(self): webbrowser.open(self._url())
    def _copy_url(self):
        self.root.clipboard_clear(); self.root.clipboard_append(self._url())
        self.log(f"copied {self._url()}")
    def _set_cfg(self, k, v):
        setattr(self.cfg, k, v); self.cfg.save()

    def log(self, line):
        ts = time.strftime("%H:%M:%S")
        text = f"[{ts}] {line}\n"
        try:
            self.log_text.config(state="normal")
            self.log_text.insert("end", text); self.log_text.see("end")
            lines = int(self.log_text.index("end-1c").split(".")[0])
            if lines > 500: self.log_text.delete("1.0", f"{lines-500}.0")
            self.log_text.config(state="disabled")
        except Exception:
            print(text, end="")

    def on_close(self):
        if self.running: self._stop_server()
        self.root.destroy()


def main():
    if not os.path.exists(DASHBOARD_HTML_PATH):
        print(f"WARNING: dashboard.html not found at {DASHBOARD_HTML_PATH}")
    root = tk.Tk()
    app = Launcher(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
