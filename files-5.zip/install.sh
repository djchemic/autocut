#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
echo ""
echo "  AUTOCUT — install"
echo ""

# ── Python 3.12 (3.13 + Tk9 crashes on macOS) ──
if ! brew list python@3.12 &>/dev/null 2>&1; then
    echo "  installing python@3.12..."
    brew install python@3.12
fi
if ! brew list python-tk@3.12 &>/dev/null 2>&1; then
    echo "  installing python-tk@3.12..."
    brew install python-tk@3.12
fi

# ── Node (for atem-connection, the Fairlight-level bridge) ──
if ! command -v node &>/dev/null && ! brew list node &>/dev/null 2>&1; then
    echo "  installing node..."
    brew install node
fi

PYTHON="$(brew --prefix)/bin/python3.12"
echo "  python: $($PYTHON --version)"
echo "  node:   $(node --version 2>/dev/null || echo 'NOT FOUND')"

# ── Require Node 18+ (atem-connection won't parse on old node) ──
NODE_MAJOR="$(node -e 'console.log(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)"
if [ "$NODE_MAJOR" -lt 18 ]; then
    echo ""
    echo "  ERROR: node $(node --version 2>/dev/null) is too old (need v18+)."
    echo "  If you use nvm:"
    echo "      nvm install --lts && nvm alias default 'lts/*' && nvm use --lts"
    echo "  Then re-run:  bash install.sh"
    exit 1
fi

if ! "$PYTHON" -c "import tkinter" 2>/dev/null; then
    echo "  ERROR: tkinter broken. Try: brew reinstall python-tk@3.12"
    exit 1
fi

echo "  installing python packages..."
"$PYTHON" -m pip install --quiet --break-system-packages "pyinstaller>=6.0" "zeroconf" "pillow"

cd "$DIR"

echo "  installing atem-connection (node)..."
if [ ! -f package.json ]; then
    npm init -y >/dev/null 2>&1
fi
npm install --silent atem-connection
# .bin holds dangling symlinks that break cp -r; not needed at runtime
rm -rf node_modules/.bin

echo "  building app (1-2 min)..."
rm -rf build dist *.spec __pycache__

# Build macOS .icns from the iconset (iconutil is macOS-only)
ICON_ARG=""
# Always regenerate the iconset so a new favicon.png actually takes effect.
# (If we skip when Autocut.iconset/ exists, stale icons get baked into the .app.)
rm -rf Autocut.iconset Autocut.icns
SRC=""
[ -f "icon-source.png" ] && SRC="icon-source.png"
[ -z "$SRC" ] && [ -f "favicon.png" ] && SRC="favicon.png"
if [ -n "$SRC" ]; then
    mkdir -p Autocut.iconset
    # Use Pillow (Python) instead of sips for the resize — sips -z destroys
    # the alpha channel on PNGs with transparent corners, leaving black corners.
    # Pillow's LANCZOS resize preserves RGBA cleanly.
    "$PYTHON" - <<PYEOF
from PIL import Image
src = Image.open("$SRC").convert("RGBA")
for sz in (16, 32, 128, 256, 512):
    for scale, suffix in ((1, ""), (2, "@2x")):
        target = sz * scale
        out = src.resize((target, target), Image.LANCZOS)
        out.save(f"Autocut.iconset/icon_{sz}x{sz}{suffix}.png", "PNG", optimize=True)
print("iconset generated with alpha preserved")
PYEOF
fi
if [ -d "Autocut.iconset" ]; then
    iconutil -c icns "Autocut.iconset" -o "Autocut.icns" 2>/dev/null && ICON_ARG="--icon Autocut.icns"
fi

"$PYTHON" -m PyInstaller \
    --noconfirm --windowed \
    --name "Autocut" \
    $ICON_ARG \
    --add-data "dashboard.html:." \
    --add-data "atem-levels.js:." \
    --add-data "favicon.png:." \
    --add-data "node_modules:node_modules" \
    --hidden-import "tkinter" \
    --hidden-import "_tkinter" \
    --collect-all "zeroconf" \
    autocut.py

rm -rf "$DIR/Autocut.app"
# remove dangling npm symlinks that break cp/rm, in both build outputs
find dist -name ".bin" -type d -exec rm -rf {} + 2>/dev/null || true
cp -R "dist/Autocut.app" "$DIR/"
find "$DIR/Autocut.app" -name ".bin" -type d -exec rm -rf {} + 2>/dev/null || true
xattr -dr com.apple.quarantine "$DIR/Autocut.app" 2>/dev/null || true

# Force Finder to refresh the app icon. macOS aggressively caches icons,
# so a new .icns inside the bundle may not show without busting the cache.
touch "$DIR/Autocut.app"
# Flush Launch Services + icon cache (best-effort, fails silently if not allowed)
/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister \
    -kill -r -domain local -domain system -domain user >/dev/null 2>&1 || true
killall Dock >/dev/null 2>&1 || true
killall Finder >/dev/null 2>&1 || true

chmod -R u+w build dist 2>/dev/null || true
rm -rf build dist *.spec __pycache__ 2>/dev/null || true

echo ""
echo "  ✓  Autocut.app ready. Opening..."
echo "     (node must stay installed — the app shells out to it)"
echo ""
open "$DIR/Autocut.app"
