#!/bin/bash
# package.sh — bundle Autocut.app for distribution to another Apple Silicon Mac.
#
# Run on YOUR Mac, in the same folder as Autocut.app and install.sh.
#   bash package.sh
# Output: Autocut-Mac-AppleSilicon.zip, ready to send.

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Autocut.app"
OUT_DIR="$DIR/Autocut-Package"
ZIP="$DIR/Autocut-Mac-AppleSilicon.zip"

echo ""
echo "  AUTOCUT — package for distribution"
echo ""

if [ ! -d "$APP" ]; then
    echo "  ERROR: $APP not found. Run install.sh first to build it."
    exit 1
fi

# Find node binary
NODE_BIN="$(command -v node || true)"
if [ -z "$NODE_BIN" ] || [ ! -f "$NODE_BIN" ]; then
    echo "  ERROR: node not found on this Mac."
    exit 1
fi
# Resolve symlinks (nvm puts node behind a couple)
NODE_REAL="$(readlink -f "$NODE_BIN" 2>/dev/null || python3 -c "import os,sys; print(os.path.realpath(sys.argv[1]))" "$NODE_BIN")"
echo "  bundling node from: $NODE_REAL"
echo "  node version:       $(node --version)"

# Verify architecture
ARCH="$(uname -m)"
if [ "$ARCH" != "arm64" ]; then
    echo "  WARNING: this Mac is $ARCH, not arm64. The package will only run on the same arch."
fi

# ── Copy the .app to a working folder so we don't modify the original ──
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"
echo "  copying Autocut.app..."
cp -R "$APP" "$OUT_DIR/Autocut.app"

# ── Bundle node binary INSIDE the .app ──
BUNDLED_NODE_DIR="$OUT_DIR/Autocut.app/Contents/MacOS/bundled-node"
mkdir -p "$BUNDLED_NODE_DIR"
cp "$NODE_REAL" "$BUNDLED_NODE_DIR/node"
chmod +x "$BUNDLED_NODE_DIR/node"
echo "  bundled node: $BUNDLED_NODE_DIR/node"

# ── Optionally include your saved scenes / config ──
USER_CFG="$HOME/Library/Application Support/Autocut/config.json"
if [ -f "$USER_CFG" ]; then
    echo "  including your saved config (scenes + presets)..."
    mkdir -p "$OUT_DIR/preset"
    cp "$USER_CFG" "$OUT_DIR/preset/config.json"
fi

# ── Write a README for the recipient ──
cat > "$OUT_DIR/README.txt" <<'README'
Autocut — for ATEM Mini Pro ISO
================================

1. Drag "Autocut.app" into /Applications (or anywhere you like).

2. First launch — macOS Gatekeeper will block it because the app isn't
   signed by Apple. Two ways to allow it:

   Easy way:   right-click Autocut.app  →  Open  →  "Open" in the dialog.
               You only do this once.

   Or in Terminal, run:
       xattr -dr com.apple.quarantine /Applications/Autocut.app
       open /Applications/Autocut.app

3. (Optional) To use the included scenes preset:
   Copy "preset/config.json" to:
       ~/Library/Application Support/Autocut/config.json
   (create the folder if it doesn't exist)

4. In the launcher window, click START SERVER, then LAUNCH GUI.
   Connect to your ATEM by IP (or pick one from the dropdown).

5. In Bitfocus Companion, point a button at this URL to toggle auto:
       POST http://localhost:8080/api/toggle

Node.js is bundled inside the app — no installation required.

Requires: macOS on Apple Silicon (M1/M2/M3/M4).
README

# ── Include the source too in case they want to rebuild or hack ──
mkdir -p "$OUT_DIR/source"
for f in autocut.py dashboard.html atem-levels.js install.sh favicon.png; do
    [ -f "$DIR/$f" ] && cp "$DIR/$f" "$OUT_DIR/source/"
done

# ── Strip quarantine and zip ──
xattr -dr com.apple.quarantine "$OUT_DIR" 2>/dev/null || true
rm -f "$ZIP"
echo "  zipping..."
cd "$DIR"
# ditto preserves macOS metadata + symlinks better than zip
ditto -c -k --sequesterRsrc --keepParent "$OUT_DIR" "$ZIP"

SIZE="$(du -h "$ZIP" | cut -f1)"
echo ""
echo "  ✓  Package ready:"
echo "     $ZIP  ($SIZE)"
echo ""
echo "  Send the zip to the other Mac. Tell them to follow README.txt."
echo ""
